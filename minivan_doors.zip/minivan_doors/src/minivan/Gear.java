package minivan;

public enum Gear {
    PARK,
    REVERSE,
    NEUTRAL,
    FIRST,
    SECOND,
    THIRD,
    DRIVE
}
